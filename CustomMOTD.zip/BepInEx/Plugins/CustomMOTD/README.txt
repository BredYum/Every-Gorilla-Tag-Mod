Custom Message Of The Day by fchb1239

Launch the game to generate the required files. Come back here to change them.


IsNewMOTD.txt should be set to either true or false - this controls if the message board should be yellow or not.

MessageOfTheDay.txt is the text that gets displayed on the message board - change that to what you want.