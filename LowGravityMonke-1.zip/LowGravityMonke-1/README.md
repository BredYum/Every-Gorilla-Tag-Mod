# LowGravityMonke
Low gravity, Just like space!
# Isnt that fun, Eh?

You have a bit less then half gravity!

![image](https://user-images.githubusercontent.com/97604500/161980288-4f5450c1-0ed4-49aa-967f-68c1076c9405.png)

^ Awesome image i drew. ^

